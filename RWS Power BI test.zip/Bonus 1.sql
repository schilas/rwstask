WITH cte_count
     AS (SELECT Count(handoffsk) AS "pocet",
                'A'              AS "lookp"
         FROM   base),
     cte_countl
     AS (SELECT sourcelanguagecode,
                Count(handoffsk) AS "pocetj",
                'A'              AS "lookp"
         FROM   base AS b
         GROUP  BY sourcelanguagecode)
SELECT sourcelanguagecode,
       pocetj,
       pocet,
       100 * ( ( pocetj * 1.0 ) / pocet ) AS "%"
FROM   cte_countl AS c1
       LEFT JOIN cte_count AS c2
              ON c1.lookp = c2.lookp
WHERE  sourcelanguagecode = 'EN-US' 