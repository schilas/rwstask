SELECT b.handoff,b.HandoffSK FROM Base as B 
where b.handoffsk in (select handoffsk from Handoff where iscurrent=0)