SELECT handoffsk,
                sourcelanguagecode,
                handoffstatename,
                handoff,
                CASE
                  WHEN b.classification = 'H' THEN '0'
                  WHEN b.classification = 'M' THEN '1'
                  WHEN b.classification = 'L' THEN '2'
                  ELSE '3'
                END AS "Priority",
                createddate,
                CASE
                  WHEN b.classification = 'H' THEN date(createddate,'+1 day')
                  WHEN b.classification = 'M' THEN date(createddate,'+3 day')
                  WHEN b.classification = 'L' THEN date(createddate,'+5 day')
                  ELSE date(createddate,'+10 day')
                END AS "Due date",
                completeddate,
                strftime('%d',completeddate) -   strftime('%d',createddate) as "Timeliness",
                CASE
                  WHEN b.classification = 'H' THEN case when handoffstatename<>'Completed' then (case when createddate<date(MD.Latest,'-1 day') then "Late" else "Not possible to assess" end) when (strftime('%d',completeddate) -   strftime('%d',createddate))<=1 then "On-time" else "Late" end
                  WHEN b.classification = 'M' THEN case when handoffstatename<>'Completed' then (case when createddate<date(MD.Latest,'-3 days') then "Late" else "Not possible to assess" end)  when (strftime('%d',completeddate) -   strftime('%d',createddate))<=3 then "On-time" else "Late" end
                  WHEN b.classification = 'L' THEN case when handoffstatename<>'Completed' then (case when createddate<date(MD.Latest,'-5 days') then "Late" else "Not possible to assess" end)  when (strftime('%d',completeddate) -   strftime('%d',createddate))<=5 then "On-time" else "Late" end
                  ELSE case when handoffstatename<>'Completed' then (case when createddate<date(MD.Latest,'-10 days') then "Late" else "Not possible to assess" end)  when (strftime('%d',completeddate) -   strftime('%d',createddate))<=10 then "On-time" else "Late" end
                END AS "SLA"
         FROM   base AS B left join (SELECT case when max(createddate)>max(completeddate) then max(createddate) else max(completeddate) end as "Latest", 'A' as "J" from Base) as MD on MD.J='A'