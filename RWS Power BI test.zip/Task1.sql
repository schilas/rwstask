WITH cte_base
     AS (SELECT handoffsk,
                sourcelanguagecode,
                handoffstatename,
                handoff,
                createddate,
                completeddate,
                classification,
                CASE
                  WHEN b.classification = 'H' THEN '0'
                  WHEN b.classification = 'M' THEN '1'
                  WHEN b.classification = 'L' THEN '2'
                  ELSE '3'
                END AS "Priority"
         FROM   base AS B)
SELECT h.handoffsk,
       h.handoffid,
       h.projectno,
       b.sourcelanguagecode,
       b.handoffstatename,
       b.handoff,
       t.createddate,
       t.completeddate,
       Sum(wordcount) AS "wordcount",
       b.classification,
       b.priority
FROM   handoff AS H
       LEFT JOIN cte_base AS B
              ON B.handoffsk = H.handoffsk
       LEFT JOIN tasks AS T
              ON T.handoffid = H.handoffid
WHERE  b.handoffstatename <> 'Canceled'
GROUP  BY h.handoffsk,
          h.handoffid,
          h.projectno,
          b.sourcelanguagecode,
          b.handoffstatename,
          b.handoff,
          t.createddate,
          t.completeddate,
          wordcount,
          priority 